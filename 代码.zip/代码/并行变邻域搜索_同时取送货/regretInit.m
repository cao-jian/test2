function [resultVC,resultVe] = regretInit(VC,removed,VE,vehicle,demands,a,b,L,s,dist,centernum,alpha,gamma,belta,types)

rfvc=VC;
count=0;
for i=1:size(VC,1)
    count=count+length(VC{i});
end
while ~isempty(removed)
    len=length(removed);
    deltaCost=zeros(len,4);
    for i=1:len
        [temp]= cheapestIP( removed(i),rfvc,VE,L,a,b,s,dist,demands,vehicle,centernum,count+length(VE),alpha,gamma,belta,types);
        deltaCost(i,:)=[removed(i) temp];
    end
    
    tempCost=sortrows(deltaCost,-4);
    removed(removed==tempCost(1,1))=[];
    count=count-1;
    rfvc=insert(tempCost(1,1),tempCost(1,2),tempCost(1,3),rfvc);
end

resultVC=rfvc;
resultVe=VE;

end