tic
a=zeros(1000,1);
for i=1:1000
    
end
toc