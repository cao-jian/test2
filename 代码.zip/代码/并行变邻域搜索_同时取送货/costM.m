function result = costM(routeM,cap,duration,demands,a,b,L,s,dist,center,centernum,alpha,gamma,belta,types)
n=size(routeM,1);
result=zeros(n,1);
for i=1:n
    if isempty(routeM(i,:))
        result(i)=0;
    else
%         if Judge(routeM(i,:),cap,duration,demands,a,b,L,s,dist,vehicle,vehicle_use,centernum)
            vio=Violate(routeM(i,:),cap,duration,demands,a,b,L,s,dist,center,centernum,alpha,gamma,belta,types);
            dis=part_length(routeM(i,:),dist,center,centernum);
            result(i)=dis+vio;
%         else
%             result(i)=inf;
%         end
    end
    
end
end