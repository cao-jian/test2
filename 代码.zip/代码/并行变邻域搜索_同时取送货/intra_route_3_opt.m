function [resultVC,resultVE]=intra_route_3_opt(VC,VE,vehicle,demands,a,b,L,s,dist,centernum,changed_route,alpha,gamma,belta,types)
NV=length(VE);
vehicle_use=VE;
cap=vehicle(1,4);
duration=vehicle(1,3);
optRotue=cell(NV,1);
optRotue=VC;
center=vehicle(vehicle_use,2);
changed_route=unique(changed_route);
changed_route=intersect(changed_route,1:NV);
for i=1:NV
    route=VC{i};
    len=length(route);
    if len>5
        comb=nchoosek(1:len,3);
%         index=(comb(:,2)-comb(:,1))>=4;
%         comb=comb(index,:);
        n=size(comb,1);
        tempRoute=zeros(8*n,len);
        constCost=costM(route,cap,duration,demands,a,b,L,s,dist,center(i),centernum,alpha,gamma,belta,types);
        for j=1:n
            temp=three_opt(route,comb(j,:));
            tempRoute(1+(j-1)*8:8+(j-1)*8,:)=temp;
        end
        
        cost=costM(tempRoute,cap,duration,demands,a,b,L,s,dist,center(i),centernum,alpha,gamma,belta,types);
        cost=constCost-cost;
        [tempC,pos]=max(cost);
        if tempC~=-inf && tempC>0
            optRotue{i}=tempRoute(pos,:);
        else
            optRotue{i}=route;
        end
    else
        
        optRotue{i}=route;
    end
    
end

resultVC=optRotue;
resultVE=vehicle_use;
end