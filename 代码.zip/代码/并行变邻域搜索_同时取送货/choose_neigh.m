function [resultVC,resultVE,changed_route]=choose_neigh(vc,ve,vehicle,demands,a,b,L,s,dist,centernum,knei,changed_route,alpha,gamma,belta,types)

switch knei
    case 1
        [resultVC,resultVE,changed_route]=inter_route_2_opt(vc,ve,vehicle,demands,a,b,L,s,dist,centernum,changed_route,alpha,gamma,belta,types);
    case 2
        [resultVC,resultVE,changed_route]=inter_route_swap(vc,ve,vehicle,demands,a,b,L,s,dist,centernum,changed_route,alpha,gamma,belta,types);
    case 3
        [resultVC,resultVE,changed_route]=inter_route_2swap(vc,ve,vehicle,demands,a,b,L,s,dist,centernum,changed_route,alpha,gamma,belta,types);
    case 4
        [resultVC,resultVE,changed_route]=inter_route_1_insert(vc,ve,vehicle,demands,a,b,L,s,dist,centernum,changed_route,alpha,gamma,belta,types);
    case 5
        [resultVC,resultVE,changed_route]=inter_route_2_insert(vc,ve,vehicle,demands,a,b,L,s,dist,centernum,changed_route,alpha,gamma,belta,types);
    case 6
        [resultVC,resultVE]=intra_route_2_opt(vc,ve,vehicle,demands,a,b,L,s,dist,centernum,changed_route,alpha,gamma,belta,types);
    case 7
        [resultVC,resultVE]=intra_route_3_opt(vc,ve,vehicle,demands,a,b,L,s,dist,centernum,changed_route,alpha,gamma,belta,types);
    case 8
        [resultVC,resultVE]=intra_route_swap(vc,ve,vehicle,demands,a,b,L,s,dist,centernum,changed_route,alpha,gamma,belta,types);
    case 9
        [resultVC,resultVE]=intra_1_insert(vc,ve,vehicle,demands,a,b,L,s,dist,centernum,changed_route,alpha,gamma,belta,types);
end
end