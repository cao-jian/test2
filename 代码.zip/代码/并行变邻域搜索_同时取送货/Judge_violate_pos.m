function result = Judge_violate_pos(VC,VE,vehicle,cap,demands,a,b,L,s,dist,centernum)
n=size(VC,1);
result=cell(n,1);
centers=vehicle(VE,2);
pos=[];
for i = 1:n
    route=VC{i};
    center=centers(i);
    if ~isempty(route)
        [bs,back,arr]= begin_s( route,a,b,s,dist,center,centernum );
        leav=b(route);
        leav=leav';
%         wait=bs-arr;
        %     vtw=arr-leav;
        vtw=arr-leav;
        pos1=find(vtw>0);

        
%         fs=feasible(leav,wait,bs);
%         vdu=max(back-0-fs-duration,0);
        
        
        init_v=cumsum(demands(route));
        pos3=find(init_v>cap);
        
        pos=union(pos1,pos3);
    end
    if isempty(pos)
        result{i}=pos;
    else
        result{i}=[];
    end
end



end