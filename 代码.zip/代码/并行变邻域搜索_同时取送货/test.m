clc;
clear all;
a=[1 2; 3 4; 5 6]
r=[1 2 3];

a=[1 2 3  4  5  6 7 8 ]
% a(1:2:end)
