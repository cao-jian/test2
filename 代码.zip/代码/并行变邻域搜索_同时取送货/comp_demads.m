function result = comp_demads(demands,comparts,route,class)
    result=zeros(class,1);
    tempde=demands(route);
    tempco=comparts(route);
    for i=1:class
        in= tempco==i;
        result(i)=sum(tempde(in));
    end
end