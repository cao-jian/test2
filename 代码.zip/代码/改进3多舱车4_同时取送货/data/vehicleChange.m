clc
clear all;
for ii=1:20
    vehicleFile=['vehicle' sprintf('%02d',ii) ];
    vehicle=importdata(['data/' vehicleFile '.txt']);
    temp1=vehicle(:,1:end-1);
    temp2=[vehicle(:,end)/3 vehicle(:,end)/3 vehicle(:,end)/3];
%     temp2=[vehicle(:,end)*0.5 vehicle(:,end)*0.5];
    temp=[temp1 temp2];
    dlmwrite(['3��/vehicle',sprintf('%02d',ii),'.txt'],temp);
end