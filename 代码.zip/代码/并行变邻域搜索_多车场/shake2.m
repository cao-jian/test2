function [resultVC ,resultVE,routeCombMap,shakeMap,changed_route] = shake2(VC,VE,vehicle,demands,cap,duration,a,b,L,s,dist,centernum,routeCombMap,lenMax,shakeMap,bestTD,alpha,gamma,belta,ksha)
%     ksha=1;
%     while 1
        [VCs,VEs,routeCombMap,shakeMap,changed_route]=choose_shake(VC,VE,vehicle,routeCombMap,lenMax,shakeMap,ksha);
        vioPos=Judge_violate_pos(VCs,VEs,vehicle,cap,demands,a,b,L,s,dist,centernum);
        [VCs,remove]=removed(VCs,vioPos);
        [resultVC,resultVE] = regretInit(VCs,remove,VEs,vehicle,demands,a,b,L,s,dist,centernum,alpha,gamma,belta);
        
%         ksha=mod(ksha,4)+1;
%         if currentCost<bestTD*1.7
%         resultVC=VCs;
%         resultVE=VEs;
%             break;
%         end
%     end
end