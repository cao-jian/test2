%% ��importdata�����������ȡ�ļ�
clc
clear all
i=1;
dataFile=['pr' sprintf('%02d',i) ]
vehicleFile=['vehicle' sprintf('%02d',i) ];
data=importdata(['data/' dataFile '.txt']);
% cap=200;                                       %�������װ����
vehicle=importdata(['data/' vehicleFile '.txt']);
BKS=importdata('data/BKS.txt');
centernum=max(vehicle(:,2));
%% ��ȡ������Ϣ
E=data(1,8);                                                    %��������ʱ�䴰��ʼʱ��
L=data(1,9);                                                    %��������ʱ�䴰����ʱ��
vertexs=data(:,2:3);                                           %���е������x��y
customer=vertexs(centernum+1:end,:);                                       %�˿�����
cusnum=size(customer,1);                                         %�˿���
v_num=size(vehicle,1);                                                        %�������ʹ����Ŀ
cen_ve=v_num/centernum;
demands=data(centernum+1:end,5)*rand(1,4);                        %������

a=data(centernum+1:end,end-1);                                                %�˿�ʱ�䴰��ʼʱ��[a[i],b[i]]
b=data(centernum+1:end,end);                                                %�˿�ʱ�䴰����ʱ��[a[i],b[i]]+
s=data(centernum+1:end,4);                                                %�ͻ���ķ���ʱ��
h=pdist(vertexs);
dist=squareform(h);                                           %��������������ǹ�ϵ�����þ����ʾ����c[i][j]=dist[i][j]
% dist=roundn(dist,-2);
bks=BKS(i);
%% ��ʼ����Ⱥ
alpha=100;
gamma=100;
belta=100;
delta1=0.2;
delta2=0.1;
cap=vehicle(1,4);
duration=vehicle(1,3);
[~,index]=sort(dist(centernum+1:end,1:centernum),2,'ascend');
index=index(:,1);
% in= index==4;
% temp=1:cusnum;
% temp=temp(in);
% vet=vertexs(temp+centernum,:);
% k=boundary(vet);
% plot(vet(k,1),vet(k,2),'*','Color','r')
% hold on
% plot(vet(:,1),vet(:,2),'.','Color','g')

resultVC=containers.Map('KeyType','double','ValueType','any');
resultVE=[];
outOfcen=[];
count=1;
for cen =1:centernum
    [~,index]=sort(dist(centernum+1:end,1:centernum),2,'ascend');
    index=index(:,1);
%     ttt=[2 15 25 23];
%     ttt=15;
    in= index==cen;
    temp=1:cusnum;
%     temp(ttt)=[];
%     in(ttt)=[];
    temp=temp(in);
    len=length(temp);
    map=containers.Map('KeyType','double','ValueType','double');
    for i=1:len
        map(i)=temp(i);
    end
    VC=CW_VRPTW([data(cen,:); data(temp+centernum,:)],cap,duration);
    n=size(VC,1);
    if n>cen_ve
        outOfcen=[outOfcen; cen n-cen_ve];
    end
    for i=1:n
        for j=1:length(VC{i})
            VC{i}(j)=map(VC{i}(j));
        end
        resultVC(count)=VC(i);
        resultVE=[resultVE cen];
        
        count=count+1;
    end
end
VC=cell(count-1,1);
for i=1:count-1
    
    temp=resultVC(i);
    VC{i}=temp{1};
end


% draw_Best(VC,vertexs,resultVE,centernum)
removed=[];
del=[];
m=size(outOfcen,1);
for i=1:m
    ind=find(resultVE==outOfcen(i,1));
    len=length(ind);
    lens=zeros(len,1);
    for j=1:len
        lens(j)=length(VC{ind(j)});
    end
    [~,index]=sort(lens);
    removed = [removed VC{ind(index(1:outOfcen(i,2)))}];
    del=[del ind(index(1:outOfcen(i,2)))];
end
len=length(del);
for i=1:len
    VC{del(i)}=[];
end
VC=deal_vehicles_customer(VC);
resultVE(del)=[];

ve2cen=vehicle(:,1:2);
len=length(resultVE);
for i=1:len
    indx=find(ve2cen(:,2)==resultVE(i),1);
    resultVE(i)=ve2cen(indx,1);
    ve2cen(indx,:)=[];
end
[VC,resultVE]=comple_VC(VC,resultVE,vehicle);


% draw_Best(VC,vertexs, vehicle,resultVE,centernum)
[bestVC,bestVE] = regretInit(VC,removed,resultVE,vehicle,demands,a,b,L,s,dist,centernum,alpha,gamma,belta);
% draw_Best(bestVC,vertexs, vehicle,bestVE,centernum)

% load VC2.mat
% load VE2.mat
% 
% bestVC={   [62   80   3   132   139   13   1]
%    [11   39   26   17   45   109   107   5   28   35   71]
%    [133   129   73   127   50   10   112   12   78   87   91] 
%    [95   114   110   119   69   40   121   88   52   14]
%    [117   75   55   67   85   57   36   61   111] 
%    [8   125   34   101   100   72   74   141   24] 
%    [51   6   4]
%    [37   79   19   70   135   105   115   83   56]
%    [118   42   38   20   103   27   31   144   99   130   32]
%    [124   60   136   89   140   47   113   44]
%    [48   134   7   90   30   77   9   131   142]
%    [2   64   137   97   102   94]
%    [123   25   126   76   116   54   120   98   49   16]
%    [92   63   143   15   41   81   23   122   96   138   84   106]
%    [86   21   66   29   65   33   93   59   82   53]  
%    [43   104   128   68   46   108   58   22   18]}
% bestVC={
% [133 129 73 127 10 112 12 78 87 91]
% [11 118 42 38 20 31 103 27 13 1 139]
% [39 62 80 3 132 26 17 45 109 107 5 28 35 71]
% [95 114 110 119 69 40 121 88 52 14]
% [37 79 19 50 72 100 74 141 24]
% [117 8 125 34 101 105 70 135 56 4 6]
% [75 55 67 85 57 36 61 111 83 115]
% [51 25 126 76 116 54 120 98 49]
% [2 134 77 30 7 90 32 94]
% [102 48 97 64 137 142 113 44 144 99 130]
% [124 136 60 140 89 9 131 47]
% [86 21 66 29 65 33 93 59 82 53]
% [92 63 41 15 143 96 138 81 122 23 84 106]
% [43 104 123 128 68 46 108 58 22 18 16]
% 
%     }
% bestVE=[1 2 3 4 5 6 7 8 9 10 11 13 14 15];




% bestVC={[37 , 105 , 155 , 144 , 35 , 5 , 27 , 92 , 168 , 116 , 167 , 147 , 186 , 175 , 158]
% [16 , 178 , 135 , 84 , 99 , 64 , 39 , 25 , 185 , 9]
% [93 , 169 , 69 , 80 , 196 , 36 , 121 , 180 , 156 , 152]
% [22 , 157 , 94 , 193 , 60 , 46 , 145 , 181 , 125 , 19]
% [72 , 54 , 71 , 75 , 13 , 108 , 86 , 165 , 184]
% [132 , 149 , 63 , 133 , 101 , 161 , 62]
% [182 , 137 , 115 , 15 , 111 , 129]
% [177 , 127 , 7 , 141]
% [83 , 153 , 77 , 112 , 29 , 154 , 85 , 11 , 76 , 42 , 192]
% [146 , 126 , 61 , 187 , 50 , 6 , 176 , 34 , 120 , 114]
% [66 , 97 , 102 , 81 , 95 , 194]
% [57 , 56 , 89 , 136 , 163 , 59 , 131 , 166 , 68 , 51]
% [110 , 70 , 142 , 17 , 159 , 78 , 74 , 18 , 139 , 190]
% [38 , 113 , 23 , 171 , 43 , 134 , 143 , 20]
% [31 , 117 , 119 , 103 , 172 , 40 , 138 , 28 , 164 , 191 , 73 , 26 , 14]
% [179 , 12 , 41 , 21 , 96 , 150 , 107 , 118 , 30 , 173 , 100 , 104]
% [128 , 87 , 32 , 88 , 58 , 10 , 47 , 106 , 183 , 52 , 170 , 195 , 160 , 45 , 53 , 67 , 148]
% [189 , 82 , 188 , 91 , 49 , 174 , 162 , 8 , 124 ]
% [98 , 33 , 130 , 122 , 79 , 65 , 140]
% [55 , 151 , 44 , 24 , 109 , 90 , 123 , 48]}
% for i=1:20
%     bestVC{i}=bestVC{i}-4;
% end
% 
% bestVE=1:20;

% bestVC={[34,19,27,3,6,48,45,11,10,7,22];
%         [16,20,33,13,8,5,29,1,4,14,28];
%         [2,23,26,18,17,25,15,30,47,24,21,12,38,40];
%         [41,36,31,44,32,39,43,42,46,9,35,37]}
% bestVE=[2,3,4,1];
% 
draw_Best(bestVC,vertexs, vehicle,bestVE,centernum)
% hold on

% Chrom=[33,65,87,72,32,47,1,100,78,42,22,88,102,2,80,48,6,10,24,14,18,103,66,85,15,30,23,26,91,46,83,71,104,63,8,13,61,52,58,106,79,21,75,40,34,49,82,35,28,107,11,57,95,29,54,89,45,90,77,4,31,108,86,43,41,70,59,84,97,81,19,93,92,38,68,27,74,98,73,62,37,69,9,17,64,16,44,99,96,67,51,50,76,3,12,53,36,56,105,60,25,55,20,39,7,5,94,101];
% Chrom=[33,65,87,72,32,47,1,100,78,42,22,88,102,2,80,48,6,10,24,14,18,103,66,85,15,30,23,26,91,46,83,71,104,63,8,13,61,52,58,106,89,79,45,45,90,77,4,31,107,11,21,75,40,34,49,82,35,28,108,43,86,19,19,93,92,38,68,27,74,97,81,73,37,69,9,17,64,16,44,98,25,95,29,57,54,59,84,99,96,67,51,50,76,3,12,53,36,56,105,60,62,55,20,39,7,5,94,101]
% Chrom=[ 86   8   13   97 ...
%     81   19   93   92   38   68   27   74   98 ...
%     73   37   69   9   17   64   16   44   99 ...
%     33   65   57   29   54   70   59   84   72   87   32   47   1   100 ...
%     95   25   60   62   55   20   39   7   5   94   101 ...
%     88   78   102 ...
%     96   67   51   50   76   3   12   53   36   71   22   103 ...
%     2   80   48   6   10   24   14   18   104 ...
%     42   85   66   56   105 ...
%     11   21   15   75   40   34   49   82   35   106 ...
%     89   41   43   63   77   90   4   31   61   52   58   107 ...
%     79   45   26   46   23   30   83   91   28   108  ]
%pr02
% Chrom=[81,19,93,92,38,68,27,74,97,86,8,13,99,95,25,60,62,55,20,39,7,5,94,100,96,67,51,50,76,3,12,53,36,71,103,11,21,15,75,40,34,49,82,35,106,79,45,26,46,23,83,30,91,28,107,89,41,43,63,77,90,4,31,61,52,58,108,33,65,57,29,54,70,59,84,72,87,32,47,1,102,2,80,48,6,10,24,14,18,105,66,85,42,22,56,104,88,78,101,73,37,69,9,17,64,16,44,98];
%pr17
% Chrom=[72	5	63	24	57	50	28	46	53	52	76	36	71	35	2	38	39	32	62	69	40	25	78	59	51	12	26	23	1	64	47	41	17	68	74	34	44	22	54	56	3	16	15	45	8	75	70	11	6	33	65	10	18	20	31	27	60	9	19	42	30	73	67	14	48	21	55	4	29	13	61	49	43	7	37	58	66	77];
%pr08
% Chrom=[129	114	39	141	116	82	27	84	93	147	140	74	127	97	106	133	149	33	37	121	119	88	126	87	32	91	151	83	107	21	100	124	52	58	60	94	89	86	95	159	54	123	44	115	13	47	66	11	17	161	92	48	2	137	31	30	131	55	81	41	136	153	109	34	35	128	113	38	16	8	90	23	50	42	10	104	150	138	85	14	105	112	157	36	67	70	79	117	6	62	76	1	64	158	63	25	51	118	18	4	103	148	142	12	120	69	49	143	9	26	110	61	22	155	122	96	80	57	29	7	73	40	145	132	65	19	154	56	135	46	24	125	15	5	139	134	3	77	108	68	45	152	71	99	75	98	130	20	78	111	43	144	72	59	162	53	102	101	28	146	156	160];
%pr13
% Chrom=[26	3	80	73	14	121	52	88	127	10	112	12	129	133	17	62	146	13	110	119	69	40	139	132	1	95	71	39	147	117	8	83	115	105	101	100	72	50	74	141	79	70	148	64	137	131	9	89	140	47	60	136	142	2	151	94	102	48	97	134	77	30	7	90	96	81	32	152	124	113	38	20	103	114	27	31	118	144	42	44	153	18	123	128	25	68	58	22	33	93	65	21	86	154	66	53	29	82	59	76	116	49	98	54	120	126	16	155	92	106	84	138	122	23	130	99	41	15	143	63	104	43	156	37	24	19	78	108	46	51	6	4	75	150	135	56	125	34	111	61	36	57	85	67	55	149	91	45	87	109	107	5	28	35	11	145]
% Chrom=[167,30,140,169,161,13,190,217,86,101,123,172,110,180,36,153,29,218,67,59,47,3,117,15,60,103,56,219,73,108,127,16,121,156,84,182,69,7,223,41,6,194,186,82,168,95,43,4,226,152,202,11,171,106,45,52,137,12,26,209,227,124,88,77,130,141,14,147,20,32,18,1,143,162,205,228,174,178,90,27,72,25,92,33,211,210,192,191,216,229,98,28,70,159,62,10,91,129,112,55,213,66,99,40,230,158,139,146,157,83,184,126,133,151,231,201,57,49,160,107,195,93,8,17,181,234,170,97,165,96,50,208,74,200,235,132,2,58,42,81,9,164,138,113,240,207,197,187,89,173,136,175,134,145,215,131,224,111,87,46,176,203,166,54,53,239,193,142,100,37,38,144,232,189,118,85,128,35,76,21,31,102,148,109,122,222,135,199,163,198,63,94,80,115,104,68,119,177,149,225,179,188,204,154,206,65,125,19,237,51,48,183,71,75,116,114,233,64,39,79,78,214,120,105,23,150,220,155,44,34,185,196,61,22,24,212,236,5,221,238];
% disp('��ʼ��Ⱥ�е�һ�����ֵ:')
% TD=travel_distance(VC,dist,vehicle,VE,centernum);
% disp(['�ܾ��룺',num2str(TD)]);
% disp(['����ʹ����Ŀ��',num2str(length(VE)),'��������ʻ�ܾ��룺',num2str(TD)]);
% disp('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
%% �Ż�
% optComb=initPointComb(cusnum);
ksMax=4;
routeCombMap=initRouteMap(vehicle);
shakeMap=initShakeMap(ksMax);
penalty=initPenalty(6,3,alpha,gamma,belta);
cap=vehicle(1,4);
duration=vehicle(1,3);
optima=inf;
bestCost=costFuction(bestVC,cap,duration,demands,a,b,L,s,dist,vehicle,bestVE,centernum,alpha,gamma,belta);
bestInCost=bestCost; %�����н�
ksha=1;
knei=1;
changed_route=1:v_num; %��¼�ı��·�����
VCs=bestVC;
VEs=bestVE;
flag=0;
for time=1:1000
    count=0;
%     paramRecord=zeros(100,2);
    while 1
        count=count+1;
%         alpha=penalty(knei,1);
%         gamma=penalty(knei,2);
%         belta=penalty(knei,3);
        currentCost=costFuction(VCs,cap,duration,demands,a,b,L,s,dist,vehicle,VEs,centernum,alpha,gamma,belta);
        if currentCost==0
            disp('hhhh')
        end
%         changed_route=1:v_num;
        [newVC,newVE,changed_route]=choose_neigh(VCs,VEs,vehicle,demands,a,b,L,s,dist,centernum,knei,changed_route,alpha,gamma,belta);
%         changed_route=1:v_num;
        newCost=costFuction(newVC,cap,duration,demands,a,b,L,s,dist,vehicle,newVE,centernum,alpha,gamma,belta);
%         [flagTw,flagDu,flagCa]=Judge_which(newVC,cap,duration,demands,a,b,L,s,dist,vehicle,newVE,centernum);
%         [alpha,gamma,belta]=updatePenalty(flagTw,flagDu,flagCa,alpha,gamma,belta,delta1,delta2);
%         penalty(knei,:)=updatePenalty(flagTw,flagDu,flagCa,penalty(knei,:),delta);java.util.concurrent.LinkedBlockingQueue 
%         if isExist([knei,newCost],paramRecord) &&  ~(~flagTw && ~flagDu && ~flagCa)
%             break;
%         else
%             paramRecord(count,:)=[knei,newCost];
%         end
%         if ~flagTw && ~flagDu && ~flagCa
            if newCost<bestCost
                bestCost=newCost
                bestVC=newVC;
                bestVE=newVE;
%                 [alpha,gamma,belta]=updatePenalty(flagTw,flagDu,flagCa,alpha,gamma,belta,delta1,delta2);
            end
%         else
%             if newCost<bestInCost
%                 bestInCost=newCost;
% %                 [alpha,gamma,belta]=updatePenalty(flagTw,flagDu,flagCa,alpha,gamma,belta,delta1,delta2);
%             end
%         end
        if abs(bestCost-bks)/bks<0.001
            flag=1;
        end
        if optima==newCost
            break;
        end
        if newCost<currentCost
            VCs=newVC;
            VEs=newVE;
            knei=1;
        else
            knei=knei+1;
            if knei==10
                optima=bestCost;
                break;
            end
        end
    end
    if flag
        break;
    end
    %     if (newCost-bestCost)<0.1*bestCost
    %         VC=newVC;
    %         VE=newVE;
    %     else
    VC=bestVC;
    VE=bestVE;
    %     end
    knei=1;
    %     while 1
    [VCs,VEs,routeCombMap,shakeMap,changed_route]=shake2(VC,VE,vehicle,demands,cap,duration,a,b,L,s,dist,centernum,routeCombMap,10,shakeMap,bestCost,alpha,gamma,belta,ksha);

    ksha=mod(ksha,4)+1;
end
bestTD=bestCost;
% bestTD=travel_distance(bestVC,dist,vehicle,bestVE,centernum);
% disp(['����ʹ����Ŀ��',num2str(length(bestVE)),'��������ʻ�ܾ��룺',num2str(bestTD)]);
% disp('-------------------------------------------------------------')
%% �ж����Ž��Ƿ�����ʱ�䴰Լ����������Լ����0��ʾΥ��Լ����1��ʾ����ȫ��Լ��
% flag=Judge(bestVC,cap,demands,a,b,L,s,dist);

% %% ������Ž����Ƿ����Ԫ�ض�ʧ���������ʧԪ�أ����û����Ϊ��
% DEL=Judge_Del(bestVC);
%% ��������·��ͼ
% draw_Best(bestVC,vertexs,vehicle,bestVE,centernum);
runTime=toc;
% end